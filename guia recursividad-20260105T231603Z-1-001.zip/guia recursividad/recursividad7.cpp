#include <iostream>

using namespace std;
bool palindromo(int vec[],int inicio,int tam){
    if(inicio==tam){
        return true;
    }
    if(vec[inicio]==vec[tam]){
        palindromo(vec,inicio+1,tam-1);
        return true;
    }
    return false;
}
int main()
{
    int vec[5]={3,2,3,2,1};
    if(palindromo(vec,0,4)==true){
        cout<<"true"<< endl;
    }else{
         cout<<"false"<< endl;
    }
    return 0;
}
