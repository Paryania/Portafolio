#include <iostream>

using namespace std;
float acumulado(float vect[],int tam){
    if(tam==0){
        return vect[0];
    }
    return vect[tam]+=acumulado(vect,tam-1);

}
float promedio(float vect[],int tam){
    if(tam==0){
        return vect[0];
    }
    return (vect[tam]+=acumulado(vect,tam-1))/tam;
}
int main()
{
    float vec[10]={1,2,3,4,5,6,7,8,9,10};
    cout <<promedio(vec,10)<< endl;
    return 0;
}
