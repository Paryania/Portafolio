#include <iostream>

using namespace std;
int acumulado(int vect[],int tam){
    if(tam==0){
        return vect[0];
    }
    return vect[tam]+=acumulado(vect,tam-1);

}
int main()
{
    int vec[10]={1,2,3,4,5,6,7,8,9,10};
    cout <<acumulado(vec,10)<< endl;
    return 0;
}
