#include <iostream>

using namespace std;
int llenar_pos(int fila,int indice){
    if(fila==1)
        return 1;//en el pico del triángulo es 1     else{
    if(indice==0 ||indice==fila-1 )//en los costados del triángulo siempre es 1
        return 1;
    else
        return llenar_pos(fila-1,indice-1)+llenar_pos(fila-1,indice);
}

int main()
{
    int fila,columna;
    cout << "ingrese la fila" << endl;
    cin>>fila;
    cout << "ingrese la columna" << endl;
    cin>>columna;
    cout<<llenar_pos(fila,columna-1)<<endl;
    return 0;
}
