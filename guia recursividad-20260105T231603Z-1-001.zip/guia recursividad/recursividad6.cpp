#include <iostream>
#include <algorithm>
using namespace std;


// Función recursivo para invertir elementos de un subarray formado
// por `arr[low, high]`
void reverse(int arr[], int low, int high)
{
    if (low < high)
    {
        swap(arr[low], arr[high]);
        reverse(arr, low + 1, high - 1);
    }
}

int main()
{
    int vec[10] = { 1, 2, 3, 4, 5,6,7,8,9,10 };
    reverse(vec, 0, 9);
    for (int i = 0; i < 10; i++) {
        cout << vec[i] << " ";
    }
    return 0;
}
