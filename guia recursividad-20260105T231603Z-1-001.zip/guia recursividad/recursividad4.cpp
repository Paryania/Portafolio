#include <iostream>

using namespace std;
int men(int vec[],int tam){
    if(tam==0){
        return vec[0];
    }else{
        int ultimo=vec[tam-1];
        int m=men(vec,tam-1);
        return (ultimo<m)?ultimo:m;
    }
}
int main()
{
    int vec[10]={11,22,3,4,5,6,7,8,9,10};
    cout <<men(vec,10)<< endl;
    return 0;
}
