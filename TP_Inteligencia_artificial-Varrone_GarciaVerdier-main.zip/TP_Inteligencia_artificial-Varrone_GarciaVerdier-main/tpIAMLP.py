import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix, classification_report
from datasets import load_dataset
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras.layers import Dense, Dropout # Sumá Dropout al import arriba
from tensorflow.keras.optimizers import Adam # Agregá esto a tus imports
# --- A. CARGA DE DATOS ---
print("Cargando dataset...")
# Descargamos el dataset desde Hugging Face
dataset = load_dataset("scikit-learn/churn-prediction")

# Convertimos la partición de entrenamiento a un DataFrame de Pandas para manipularlo más fácil
df = dataset['train'].to_pandas()

# --- B. PREPROCESAMIENTO ---
print("Preprocesando datos...")
# 1. Separar las características (X) de la variable objetivo (y)
# (Asegurate de verificar si la columna objetivo se llama 'churn' o 'class' imprimiendo df.columns)
target_column = 'Churn' 
X = df.drop(columns=[target_column])
y = df[target_column]
# Convertir la columna objetivo a ceros y unos
encoder = LabelEncoder()
y = encoder.fit_transform(y)

# 2. Convertir variables categóricas (texto) a números (One-Hot Encoding)
X = pd.get_dummies(X, drop_first=True)

# 3. Separar en datos de entrenamiento y prueba (80% train, 20% test)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 4. Escalar los datos (las redes neuronales funcionan mejor cuando los valores están entre -1 y 1 o 0 y 1)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)


#########################################################################################
# --- C. CREACIÓN DEL MODELO SECUENCIAL (MLP) ---
print("Construyendo la red neuronal...")
modelo = Sequential()

# # Capa de entrada y primera capa oculta (Input layer & Hidden Layer 1)
# # 'input_shape' debe coincidir con la cantidad de columnas de nuestros datos de entrenamiento
modelo.add(Dense(32, activation='relu', input_shape=(X_train_scaled.shape[1],)))

# # Segunda capa oculta (Hidden Layer 2)
modelo.add(Dense(16, activation='relu'))

# # Capa de salida (Output Layer)
# # IMPORTANTE: Al ser clasificación binaria, usamos 1 neurona y función de activación 'sigmoid'
modelo.add(Dense(1, activation='sigmoid'))

#########################################################################################
#Primer orueba de variar parametros DROPOUT
# modelo = Sequential()
# modelo.add(Dense(32, activation='relu', input_shape=(X_train_scaled.shape[1],)))
# modelo.add(Dropout(0.5)) # Apaga el 50% de las neuronas en cada paso
# modelo.add(Dense(16, activation='relu'))
# modelo.add(Dropout(0.5)) # Apaga el 50% de las neuronas
# modelo.add(Dense(1, activation='sigmoid'))

#################################################################
#prueba 3 bajar complejidad
# modelo = Sequential()
# modelo.add(Dense(8, activation='relu', input_shape=(X_train_scaled.shape[1],))) # De 32 a 8
# modelo.add(Dense(4, activation='relu')) # De 16 a 4
# modelo.add(Dense(1, activation='sigmoid'))
#########################################################################################

# --- D. COMPILACIÓN DEL MODELO ---
# Usamos 'binary_crossentropy' porque es el estándar para clasificar entre 0 y 1.
# modelo.compile(optimizer='adam', 
#                loss='binary_crossentropy', 
#                metrics=['accuracy'])

# # Resumen de la arquitectura de tu red
# modelo.summary()
########################################3
#prueba 4 bajar learning rate

# Creamos el optimizador con una tasa más lenta (0.0001 en vez del default 0.001)
optimizador_lento = Adam(learning_rate=0.0001)

modelo.compile(optimizer=optimizador_lento, # Usamos el optimizador modificado
               loss='binary_crossentropy', 
               metrics=['accuracy'])
###################################################
# --- E. ENTRENAMIENTO (FIT) ---
print("Iniciando entrenamiento...")
# # Entrenamos el modelo. 'epochs' es la cantidad de veces que la red verá el dataset completo.
historial = modelo.fit(X_train_scaled, y_train, 
                       epochs=20, 
                       batch_size=32, 
                       validation_split=0.2) # Usamos un 20% del train para validar en cada epoch

print("¡Modelo entrenado con éxito!")

#######################################################
#prueba 2 pesos de clase
# # --- E. ENTRENAMIENTO (FIT) ---
# print("Iniciando entrenamiento...")

# # Definimos que equivocarse en la clase 1 "cuesta" 3 veces más
# pesos_clases = {0: 1.0, 1: 3.0} 

# historial = modelo.fit(X_train_scaled, y_train, 
#                        epochs=20, 
#                        batch_size=32, 
#                        class_weight=pesos_clases, # ¡Acá sumamos el hiperparámetro!
#                        validation_split=0.2)
###################################################

# --- F. EVALUACIÓN Y RESULTADOS ---
print("Generando predicciones...")
# 1. Hacemos que la red prediga sobre los datos que nunca vio (X_test)
y_pred_prob = modelo.predict(X_test_scaled)

# Como usamos 'sigmoid', la red devuelve probabilidades (ej: 0.85). 
# Todo lo mayor a 0.5 lo convertimos a 1 (se da de baja), y lo menor a 0.5 lo pasamos a 0 (se queda).
y_pred = (y_pred_prob > 0.5).astype(int)

# 2. Reporte de Métricas (Acá tenés Accuracy, Recall, Precision y F1)
print("\n--- REPORTE DE CLASIFICACIÓN ---")
print(classification_report(y_test, y_pred))

# 3. Gráficos para el informe
plt.figure(figsize=(12, 5))

# Gráfico A: Pérdida (Loss) para analizar Overfitting
plt.subplot(1, 2, 1)
plt.plot(historial.history['loss'], label='Pérdida Entrenamiento')
plt.plot(historial.history['val_loss'], label='Pérdida Validación')
plt.title('Evolución del Error (Loss)')
plt.xlabel('Épocas (Epochs)')
plt.ylabel('Binary Crossentropy')
plt.legend()
plt.grid(True)

# Gráfico B: Matriz de Confusión
plt.subplot(1, 2, 2)
cm = confusion_matrix(y_test, y_pred)
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
            xticklabels=['No Churn (0)', 'Churn (1)'], 
            yticklabels=['No Churn (0)', 'Churn (1)'])
plt.title('Matriz de Confusión')
plt.xlabel('Predicción de la Red')
plt.ylabel('Valor Real')

plt.tight_layout()
plt.show()