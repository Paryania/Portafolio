#include <iostream>
#include <string>
using namespace std;

int main(int argc, char *argv[]) {
	string correo,correo2;
	cout<<"ingrese correo electronico:";
	getline (cin,correo);
	int n=correo.find(".com");
	int x=correo.size();
	correo2=correo.substr(2,x-5);
	int y=correo2.find("@");
	int z=correo.find(" ");
	if ((n!=-1)&&(y!=-1)&&(z==-1)){
		cout<<"direccion de correo valida";
	}else cout<<"direcci�n de correo INVALIDA";
	return 0;
}

