#include <iostream>
#include <string>
using namespace std;

int main(int argc, char *argv[]) {
	string n,a,cumple,f;
	cout<<"ingrese nombre:";
	getline(cin,n);
	cout<<"ingrese apellido:";
	getline(cin,a);
	cout<<"ingrese fecha de nacimiento (DD/MM/AAAA):";
	getline(cin,cumple);
	cout<<"ingrese facultad:";
	getline(cin,f);
	cout<<n[0]+a+cumple.substr(0,2)+cumple.substr(3,2)+"@"+f+".edu.ar";
	return 0;
}

