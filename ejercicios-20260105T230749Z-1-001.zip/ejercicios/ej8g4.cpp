#include <iostream>
#include <string>
using namespace std;

int main(int argc, char *argv[]) {
	string c1,c2;
	cout<<"ingrese cadena de caracteres:";
	getline(cin,c1);
	int n=c1.find(" ");
	int x=c1.size();
	c2=c1.substr(n+1,x);
	int y=c2.find(" ");
	cout<<c2.substr(0,y);
	return 0;
}

