#include <iostream>
#include <fstream>
using namespace std;
int valory(int,int,int,int);
int main(int argc, char *argv[]) {
	ofstream archivo;
	archivo.open("./ej1g8.txt");
	if(archivo.fail()){
		cout<<"error al abrir archivo";
		return 1;
	}
	int a,b,c,y;
	cout<<"ingrese el valor de a: ";
	cin>>a;
	cout<<"ingrese el valor de b: ";
	cin>>b;
	cout<<"ingrese el valor de c: ";
	cin>>c;
	for(int i=1;i<=1000;i++){
		y=valory(i,a,b,c);
		archivo<<i<<"   "<<y<<endl;
	}
	
	return 0;
}

int valory(int x,int a,int b,int c){
	int y;
	y=((a*x*x)+(b*x)+c);

	return y;
}
