#include <iostream>
#include <string>
using namespace std;

int main(int argc, char *argv[]) {
	string p[100];
	int n,i;
	cout<<"ingrese cantidad de palabras: ";
	cin>>n;
	for (i=0;i<n;i++){
		cout<<"ingrese "<<(i+1)<<"� palabra: ";
		cin>>p[i];
	}
	for (i=0;i<n;i++){
		cout<<"vector original: "<<p[i]<<endl;
	}
	for (i=0;i<n;i++){
		cout<<"vector intercambiado: "<<p[n-1-i]<<endl;
	}
	return 0;
}

