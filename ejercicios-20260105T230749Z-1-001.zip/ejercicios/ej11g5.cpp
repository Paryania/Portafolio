#include <iostream>
#include <conio.h>
#include <iomanip>
#include <time.h>
using namespace std;
//con matrices grandes no hace todas las columnas
int main(int argc, char *argv[]) {
	srand(time(NULL));
	int N=rand()%20+1;//aumentar porcentaje para tener matrices mas grandes
	int M[10][10],i,j,cont=0;
	cout<<"Tama�o de la matriz: "<<N<<endl;
for (i=0;i<N;i++){
	for (j=0;j<N;j++){
		M[i][j]=rand()%20+1;//aumentar porcentaje para tener matrices mas grandes
		cout<<setw(3)<<M[i][j]<<" ";
		cont++;
	}
	cout<<endl;
	}
	cout<<"cantidad generada: "<<cont;

	return 0;
}

