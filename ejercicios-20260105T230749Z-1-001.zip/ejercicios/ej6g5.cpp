#include <iostream>
#include <string>
using namespace std;

int main(int argc, char *argv[]) {
	string nombre[100];
	int i;
	cout<<"ingrese nombre de los compradores del bono"<<endl;
	for (i=0;i<100;i++){
	//cout<<"ingrese nombre del comprador del bono "<<(i+1)":";
	getline(cin,nombre[i]);
	}
	cout<<"Nro bono     persona que adquirio el bono: "<<endl;
	for (i=0;i<100;i++){
	cout<<(i+1)<<"                "<<nombre[i]<<endl;
	}
	return 0;
}

