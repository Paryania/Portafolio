#include <iostream>
using namespace std;

int main(int argc, char *argv[]) {
	int z[10],i,n=10;
	for (i=0; i<n; i++){
		cout<<"ingrese n�mero entero:";
		cin>>z[i];
	}
	for (i=0; i<n; i++){
		cout<<z[9-i]<<" ";
	}
	return 0;
}

