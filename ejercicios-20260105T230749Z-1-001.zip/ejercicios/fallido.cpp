#include <iostream>
#include <string>
using namespace std;
int const n=3;//son 25
int main(int argc, char *argv[]) {
	string nombre[n],tipo,aux1,mayor;
	int codigo[n],aux2,empleado=0,mayorcant=0;
	float monto[n][2]={0},montomov,aux3,saldo[n]={0},aux4,montomayor;
	for(int i=0;i<n;i++){
		codigo[i]=0;
	}
	for(int i=0;i<n;i++){
		cout<<"ingrese codigo de empleado:";
		cin>>codigo[i];
		cout<<"ingrese nombre de empleado:";
		cin>>nombre[i];
		cout<<"ingrese monto incial de empleado:";
		cin>>monto[i][0];
	}
	cout<<"movimientos del mes"<<endl;
	int cont1=0,cod,cant,cont2=0,dia;
	while(cont1!=n){
		cont2=0;
		cout<<"ingrese codigo de empleado:";
		cin>>cod;
		cout<<"ingrese cantidad de movimientos en el mes:";
		cin>>cant;
		while(cont2!=cant){
			cout<<"ingrese dia del movimiento "<<(cont2+1)<<":";
			cin>>dia;
			cout<<"ingrese monto del movimiento: ";
			cin>>montomov;
			cout<<"ingrese tipo de extraccion:";
			cin>>tipo;
			monto[cod][1]+=montomov;
			cont2++;
		}
		saldo[cod]=(monto[cod][0]-monto[cod][1]);
		if(monto[cod][1]>monto[cod][0]){
			empleado++;
		}
		if(cant>mayorcant){
			mayorcant=cant;
			mayor=nombre[cod];
			montomayor=monto[cod][1];
		}
		cont1++;
	}
	for(int i=0;i<(n-1);i++){
		for(int j=i+1;j<n;j++){
			if(nombre[i]>nombre[j]){
				aux1=nombre[i];
				nombre[i]=nombre[j];
				nombre[j]=aux1;
				aux2=codigo[i];
				codigo[i]=codigo[j];
				codigo[j]=aux2;
				aux3=monto[i][0];
				monto[i][0]=monto[j][0];
				monto[j][0]=aux3;
				aux4=saldo[i];
				saldo[i]=saldo[j];
				saldo[j]=aux4;
			}
		}
	}
	cout<<"Cgo. empleado    Nombre del empleado    Mto asignado   Saldo"<<endl;
	for(int i=0;i<n;i++){
		cout<<codigo[i]<<"    "<<nombre[i]<<"    "<<monto[i][0]<<"    "<<saldo[i]<<endl;
	}
	cout<<"empleados que superaron el monto inicial: "<<empleado<<endl;
	cout<<"empleado que mas compras efectuo: "<<mayor<<"   "<<"monto: $"<<montomayor;
	return 0;
}

