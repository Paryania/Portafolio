#include <iostream>
#include <string>
using namespace std;
int const n=3;//son 2500
int main(int argc, char *argv[]) {
	string productos[n][2];
	int stock[n];
	float precio[n]={0};
	for (int i=0;i<n;i++){
		cout<<"ingrese codigo de producto:";
		getline(cin,productos[i][0]);
		cout<<"ingrese descripcion:";
		getline(cin,productos[i][1]);
		cout<<"ingrese stock inicial:";
		cin>>stock[i];
		cout<<"ingrese precio:";
		cin>>precio[i];
		cin.ignore();
	}
	cout<<"datos de ventas"<<endl;
	string cod;
	int pos,cant,canttot[n]={0},total=0;
	cout<<"ingrese codigo de producto:";
	cin>>cod;
	while(cod!="X975ZR"){
		int i=0;
		while (i<n){
			if(cod==productos[i][0]){
				pos=i;
				i=n;
			}
			i++;
		}
		cout<<"ingrese cantidad vendida:";
		cin>>cant;
		canttot[pos]+=cant;
		cout<<"ingrese codigo de producto:";
		cin>>cod;
	}
	cout<<"cgo. producto    descripcion    stock inicial    stock final:"<<endl;
	for (int i=0;i<n;i++){
		total+=(canttot[i]*precio[i]);
		cout<<productos[i][0]<<"      "<<productos[i][1]<<"      "<<stock[i]<<"      "<<(stock[i]-canttot[i])<<endl;
	}
	cout<<"total recaudado por ventas: $"<<total<<endl;
	cout<<"cgo. de producto    stock final ponderado"<<endl;
	for(int i=0;i<n;i++){
		cout<<productos[i][0]<<"   "<<(stock[i]-canttot[i])*precio[i]<<endl;
	}
	return 0;
}

