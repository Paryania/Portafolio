#include <iostream>
#include <string>
using namespace std;

int main(int argc, char *argv[]) {
	int mm;
	int max=0;
	int mm1=0,mm2=0,mm3=0,mm4=0,mm5=0,mm6=0;
	string ciudad,cmax;
	cout<<"ingrese cantidad de mm llovidos: ";
	cin>>mm;
	while (mm!=0){
	cout<<"ingrese ciudad en la que llovi�: ";
	getline(cin,ciudad);
	if ((mm>0)&&(mm<100)){
		mm1++;
	}
	if ((mm>100)&&(mm<200)){
		mm2++;
	}
	if ((mm>200)&&(mm<300)){
		mm3++;
	}
	if ((mm>300)&&(mm<400)){
		mm4++;
	}
	if ((mm>400)&&(mm<500)){
		mm5++;
	}
	if (mm>500){
		mm6++;
	}
	if (mm>max){
		max=mm;
		cmax=ciudad;
	}
	cout<<"ingrese cantidad de mm llovidos: ";
	cin>>mm;
	}
	cout<<"lluvias de [0,100): "<<mm1<<endl;
	cout<<"lluvias de [100,200): "<<mm2<<endl;
	cout<<"lluvias de [200,300): "<<mm3<<endl;
	cout<<"lluvias de [300,400): "<<mm4<<endl;
	cout<<"lluvias de [400,500): "<<mm5<<endl;
	cout<<"lluvias de [500 o m�s): "<<mm6<<endl;
	cout<<"ciudad con mas lluvias: "<<cmax<<" cantidad llovida: "<<max<<" mm";
	return 0;
}

