#include <iostream>
using namespace std;
int const n=5; 
int main(int argc, char *argv[]) {
	float precio[n],litros[31][6]={0},lts,tipoI=0,tipoV=0,lmenor=999,total=0;
	int tipo,dia,surtidor,diamenor;
	for (int i=0;i<n;i++){
		cout<<"ingrese  precio del combustible "<<(i+1)<<":";
		cin>>precio[i];
	}
	cout<<"datos de ventas de septiembre:"<<endl;
	cout<<"ingrese tipo de combustible (1 a 5):";
	cin>>tipo;
	while (tipo!=0){
		cout<<"ingrese dia de la venta (1 a 30):";
		cin>>dia;
		cout<<"ingrese surtidor (1 a 6):";
		cin>>surtidor;
		cout<<"ingrese litros:";
		cin>>lts;
		total+=lts;
		switch(surtidor){
			case 1:litros[dia][0]+=lts;
				break;
			case 2:litros[dia][1]+=lts;
				break;
			case 3:litros[dia][2]+=lts;
				break;
			case 4:litros[dia][3]+=lts;
				break;
			case 5:litros[dia][4]+=lts;
				break;
			case 6:litros[dia][5]+=lts;
				break;
		}
		if (tipo==1){
			tipoI+=lts;
		}
		if(tipo==5){
			tipoV+=lts;
		}
		cout<<"ingrese tipo de combustible:";
		cin>>tipo;
	}
	cout<<"total de litros"<<endl;
	cout<<" dia   surt. 1    surt. 2    surt. 3   surt. 4    surt. 5     surt. 6"<<endl;
	for(int i=0;i<30;i++){
		cout<<(i+1)<<"  ";
		for(int j=0;j<6;j++){
			cout<<litros[i+1][j]<<"   ";
			if(litros[i][5]<lmenor){
				lmenor=litros[i][5];
				diamenor=i+1;
			}
		}
		cout<<endl;
		
	}
	int porcentaje=((tipoV*100)/total);
	cout<<"total recaudado en el mes: $"<<(tipoI*precio[0])<<endl;
	cout<<"porcentaje tipo 5: "<<porcentaje<<"%"<<endl;
	cout<<"el dia que el surtidor 6 registro menos ventas fue: "<<diamenor<<" de septiembre";
	return 0;
}

