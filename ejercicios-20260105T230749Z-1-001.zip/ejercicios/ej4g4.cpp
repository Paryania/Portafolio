#include <iostream>
#include <string>
using namespace std;

int main(int argc, char *argv[]) {
	int X,n;
	string c1,c2;
	cout<<"ingrese la cadena de caracteres inicial:";
	getline (cin,c1);
	cout<<"ingrese la cadena a incorporar (recuerde hacer un espacio al final):";
	getline(cin,c2);
	cout<<"ingrese el valor donde desee incorporar la segunda cadena:";
	cin>>X;
	n=c1.size();
		if (X<=n){
		c1.insert(X,c2);
		cout<<c1;
		}else cout<<"posici�n invalida";
	
	return 0;
}

