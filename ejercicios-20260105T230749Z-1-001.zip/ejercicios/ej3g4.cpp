#include <iostream>
#include <string>
using namespace std;

int main(int argc, char *argv[]) {
	string c1,c2,c3;
	int n=0;
	cout<<"ingrese primer cadena de caracteres:";
		getline(cin,c1);
	cout<<"ingrese segunda cadena de caracteres:";
	getline(cin,c2);
	cout<<"ingrese tercer cadena de caracteres:";
	getline(cin,c3);
	n=c1.find(c2);
	if (n==-1){
		cout<<"la segunda cadena no esta incluida dentro de la primera"<<endl;
	}else 
		cout<<"la segunda cadena esta incluida dentro de la primera"<<endl;
	n=c1.find(c3);
	if (n==-1){
		cout<<"la tercer cadena no esta incluida dentro de la primera"<<endl;
	}else 
		cout<<"la tercer cadena esta incluida dentro de la primera"<<endl;
	n=c2.find(c1);
	if (n==-1){
		cout<<"la primera cadena no esta incluida dentro de la segunda"<<endl;
	}else 
		cout<<"la primera cadena esta incluida dentro de la segunda"<<endl;
	n=c2.find(c3);
	if (n==-1){
		cout<<"la tercer cadena no esta incluida dentro de la segunda"<<endl;
	}else 
		cout<<"la tercer cadena esta incluida dentro de la segunda"<<endl;
	n=c3.find(c1);
	if (n==-1){
		cout<<"la primer cadena no esta incluida dentro de la tercera"<<endl;
	}else 
		cout<<"la primer cadena esta incluida dentro de la tercera"<<endl;
	n=c3.find(c2);
	if (n==-1){
		cout<<"la segunda cadena no esta incluida dentro de la tercera"<<endl;
	}else 
		cout<<"la segunda cadena esta incluida dentro de la tercera"<<endl;
	return 0;
}

