#include <iostream>
#include <cstdlib>
using namespace std;
bool validar(char &);
int doble(int &);
bool paridad(int &);
int potencia(int &);
int main(int argc, char *argv[]) {
	char opcion;
	cout<<"CALCULOS"<<endl;
	cout<<"A- Calcular el doble de un dato."<<endl;
	cout<<"B- Determinar si es par."<<endl;
	cout<<"C- Determinar su 5ta potencia."<<endl;
	cout<<"D- Salir."<<endl;
	cout<<"Elija una opcicon (A...D): ";
	cin>>opcion;
	if(!validar(opcion)){
		cout<<"error al ingresar dato";
		exit(1);
	}
	if (opcion=='A'){
		int entero;
		cout<<"ingrese dato a calcular su doble: ";
		cin>>entero;
		doble(entero);
	} if (opcion=='B'){
		int entero;
		cout<<"ingrese dato a determinar su paridad: ";
		cin>>entero;
		if (!paridad(entero)){
			cout<<"no es par";
		}else{
			cout<<"es par";
		}
	}if (opcion=='C'){
		int entero;
		cout<<"ingrese dato a determinar su potencia: ";
		cin>>entero;
		potencia(entero);
	}else{
		exit(1);
	}
	return 0;
}

bool validar(char &x){
	if ((x!='A')||(x!='B')||(x!='C')||(x!='D')){
		return true;
	}
	return false;
}
	int doble(int &x){
		int d=0;
		d=2*x;
		cout<<"el doble es: "<<d;
		return d;
	}
bool paridad(int &y){
	int resultado=y%2;
	if(resultado!=0){
		return false;
	}
	return true;
}
	int potencia(int &z){
		int pot=0;
		pot=z*z*z*z*z;
		cout<<"la quinta potencia es: "<<pot;
		return pot;
	}
