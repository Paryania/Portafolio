#include <iostream>
using namespace std;

int main(int argc, char *argv[]) {
	int NUM[10],i,P=0,M=0,iM=0,im=0,m=999,otro;
	bool encontro=false;
	for (i=0;i<10;i++)
	{
		cout<<"escribir numero entero "<<(i+1)<<":";
	cin>>NUM[i];
	if (NUM[i]%2==0) 
	{
		P++;
	}
	if (NUM[i]>M){
		M=NUM[i];
		iM=i;
	}
	if (NUM[i]<m)
	{
	m=NUM[i];
	im=i;
	}
	}
	cout<<"numeros pares: "<<P<<endl;
	cout<<"numero mayor: "<<M<<" en la posici�n: "<<(iM+1)<<endl;
	cout<<"numero menor: "<<m<<" en la posici�n: "<<(im+1)<<endl;
	cout<<"ingrese cualquier numero entero:";
	cin>>otro;
	//i=0;
	//while ((i<10)&&(!encontro)){  //BUSQUEDA
	for (i=0;i<10;i++){
	if (NUM[i]==otro){
		encontro=true;
		i=10;
	}}
	if (encontro){
		cout<<"el numero buscado esta en el arreglo";
	}else{
		cout<<"el numero buscado no esta en el arreglo";
	}
	return 0;
}

