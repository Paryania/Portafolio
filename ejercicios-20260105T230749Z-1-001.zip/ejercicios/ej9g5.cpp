#include <iostream>
using namespace std;
int main(int argc, char *argv[]) {
	int m[3][3],i,j,n;
	for (i=0;i<4;i++)
		for (j=0;j<4;j++)
	{
			cout<<"ingrese elemento que se guardara en la fila: "<<i<<" y la columna: "<<j<<" :";
			cin>>m[i][j];
		}
		cout<<"ingrese el valor de la fila a mostrar:";
		cin>>n;
		for (j=0;j<4;j++){
				cout<<m[n][j];
			}
	return 0;
}

