#include <iostream>
#include <string>
using namespace std;
int const n=3;//son 40
int main(int argc, char *argv[]) {
	string prod[n][2],cod;
	int stock[n][2]={0},cant,pos;
	float precio[n]={0},total=0;
	for (int i=0;i<n;i++){
		cout<<"ingrese codigo del producto "<<(i+1)<<":";
		getline(cin,prod[i][0]);
		cout<<"ingrese descripcion:";
		getline(cin,prod[i][1]);
		cout<<"ingrese stock inicial:";
		cin>>stock[i][0];
		cout<<"ingrese precio:";
		cin>>precio[i];
		cin.ignore();
	}
	cout<<"VENTAS"<<endl;
	cout<<"ingrese codigo de producto:";
	cin>>cod;
	while(cod!="X9Z01"){
		int i=0;
		while(i<n){
			if(prod[i][0]==cod){
				pos=i;
				i=n;
			}
			i++;
		}
		cout<<"ingrese cantidad vendida:";
		cin>>cant;
		stock[pos][1]+=cant;
		total+=(precio[pos]*cant);
		cout<<"ingrese codigo de producto:";
		cin>>cod;
	}
	cout<<"CGO. PRODUCTO    DESCRIPCION    STOCK INICIAL    STOCK FINAL"<<endl;
	for(int i=0;i<n;i++){
		cout<<prod[i][0]<<"    "<<prod[i][1]<<"     "<<stock[i][0]<<"   "<<(stock[i][0]-stock[i][1])<<endl;
	}
	cout<<"total recaudado: $"<<total<<endl;
	cout<<"CGO. PRODUCTO     STOCK FINAL PONDERADO"<<endl;
	for(int i=0;i<n;i++){
		cout<<prod[i][0]<<"    "<<((stock[i][0]-stock[i][1])*precio[i])<<endl;
	}
	return 0;
}

