#include <iostream>
#include <string>
using namespace std;

int main(int argc, char *argv[]) {
	string c1;
	cout<<"ingrese una cadena que contenga la palabra 'pero':";
	getline (cin,c1);
	int n=c1.find("pero");
	c1.replace(n,4,"sin embargo");
	cout<<c1;
	return 0;
}

