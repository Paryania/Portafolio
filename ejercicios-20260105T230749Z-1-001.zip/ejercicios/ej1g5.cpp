#include <iostream>
using namespace std;

int main(int argc, char *argv[]) {
	int cant,pos, numeros[100];
	cout<<"ingrese cantidad de alumnos:";
	cin>>cant;
	for(int i=0;i<cant;i++){
		cout<<"ingrese la edad"<<(i+1)<<": ";
		cin>>numeros[i];
	}
	cout<<"ingrese la posici�n a informar:";
	cin>>pos;
	while((pos>0)&&(pos<=cant)){
	cout<<numeros[pos-1];
	cout<<endl<<"ingrese la posici�n a informar:";
	cin>>pos;
	}
	cout<<"la posici�n"<<pos<<"no es valida";
	return 0;
}

