#include <iostream>
using namespace std;
int mayor(int &,int &,int &);
int x,y,z;
int main(int argc, char *argv[]) {
	cout<<"ingrese numero entero: ";
	cin>>x;
	cout<<"ingrese numero entero: ";
	cin>>y;
	cout<<"ingrese numero entero: ";
	cin>>z;
	int valormayor=mayor(x,y,z);
	cout<<"el numero mayor es: "<<valormayor;
	return 0;
}
int mayor(int &x,int &y,int &z){
	int nummayor;
	if ((x>y)&&(x>z)){
		nummayor=x;
	}else if ((y>x)&&(y>z)){
		nummayor=y;
	}else{
		nummayor=z;
	}
	return nummayor;
}
