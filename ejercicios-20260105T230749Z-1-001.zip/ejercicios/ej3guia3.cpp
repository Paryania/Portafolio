#include <iostream>
using namespace std;

int main(int argc, char *argv[]) {
	int N,C=1;
	cout<<"ingrese numero entero:";
	cin>>N;
	while (C<=10)
	{
		cout<<N<<" . "<<C<<"="<<N*C<<endl;
		C++;
	}
	return 0;
}

