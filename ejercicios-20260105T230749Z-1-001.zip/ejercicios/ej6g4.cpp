#include <iostream>
#include <string>
using namespace std;

int main(int argc, char *argv[]) {
	string c1;
	cout<<"ingrese cadena de caracteres:";
	getline(cin,c1);
	int n=c1.find(" ");
	if (n!=-1){
		cout<<"tiene mas de una palabra"<<endl;
	}else cout<<"no tiene mas de una palabra"<<endl;
	char UL=c1[c1.size()-1];
	cout<<"primer letra: "<<c1[0]<<endl<<"ultima letra: "<<UL;
	return 0;
}

