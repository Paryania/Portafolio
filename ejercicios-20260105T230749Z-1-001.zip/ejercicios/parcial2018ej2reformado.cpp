#include <iostream>
#include <string>
using namespace std;
int const n=3;///son 25
int main(int argc, char *argv[]) {
	int codigo[n]={0},cod,cant,dia;
	string nombre [n],tipo,nombremayor;
	float monto[n][2]={0},montomoviemiento,saldo[n]={0},compramayor=0,montomayor=0;
	for(int i=0;i<n;i++){
		cout<<"ingrese codigo de empleado:";
		cin>>codigo[i];
		cin.ignore();
		cout<<"ingrese nombre de empleado:";
		getline(cin,nombre[i]);
		cout<<"ingrese monto de empleado:";
		cin>>monto[i][0];
	}
	cout<<"datos de moviemientos del mes"<<endl;
	int cont1=0,pos,empleado=0;
	while(cont1!=n){
		cont1++;
		int compra=0;
		cout<<"ingrese codigo de empleado:";
		cin>>cod;
		cout<<"ingrese cantidad de movimientos:";
		cin>>cant;
		int i=0;
		while (i<n){
			if(codigo[i]==cod){
				pos=i;
				i=n;
			}
			i++;
		}
		int cont2=0;
		while (cont2!=cant){
			cont2++;
			cout<<"ingrese dia del movimiento "<<(cont2)<<":";
			cin>>dia;
			cout<<"ingrese monto del movimiento:";
			cin>>montomoviemiento;
			cout<<"ingrese tipo de movimiento:";
			cin>>tipo;
			monto[pos][1]+=montomoviemiento;
			if(tipo=="C"){
				compra++;
			}
		}
		if (compra>compramayor){
			compramayor=compra;
			nombremayor=nombre[pos];
			montomayor=monto[pos][1];
		}
		if (monto[pos][1]>monto[pos][0]){
			empleado++;
		}
		saldo[pos]=(monto[pos][0]-monto[pos][1]);
	}
	string aux1;
	int aux2;
	float aux3,aux4;
	for(int i=0;i<(n-1);i++){
		for(int j=(i+1);j<n;j++){
			if (nombre[i]>nombre[j]){
				aux1=nombre[i];
				nombre[i]=nombre[j];
				nombre[j]=aux1;
				aux2=codigo[i];
				codigo[i]=codigo[j];
				codigo[i]=aux2;
				aux3=monto[i][0];
				monto[i][0]=monto[j][0];
				monto[j][0]=aux3;
				aux4=saldo[i];
				saldo[i]=saldo[j];
				saldo[j]=aux4;
			}
	}}
	cout<<"cgo. empleado    nombre empleado   mto asignado    saldo"<<endl;
	for(int i=0;i<n;i++){
		cout<<codigo[i]<<"    "<<nombre[i]<<"    "<<monto[i][0]<<"    "<<saldo[i]<<endl;
	}
	cout<<"empleados que superaron el monto inicial: "<<empleado<<endl;
	cout<<"empleados realizo mas compras: "<<nombremayor<<"   monto: $"<<montomayor;
	return 0;
}

