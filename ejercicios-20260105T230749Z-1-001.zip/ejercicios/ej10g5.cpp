#include <iostream>
#include <conio.h>
using namespace std;
//tuve que buscarlo en internet porque no se me ocurrio lo del auxiliar
int main(int argc, char *argv[]) {
	int m[4][4],i,j,f1,f2,aux;
	for (i=0;i<4;i++)
		for (j=0;j<4;j++)
	{
			cout<<"ingrese elemento que se guardara en la fila: "<<i<<" y la columna: "<<j<<" :";
			cin>>m[i][j];
		}
		cout<<"ingrese n�mero de fila a cambiar:";
		cin>>f1;
		cout<<"ingrese n�mero de fila a cambiar con la anterior:";
		cin>>f2;
		for (j=0;j<4;j++){
				aux=m[f1][j];
				m[f1][j]=m[f2][j];
				m[f2][j]=aux;
			}
		for (i=0;i<4;i++)
			for (j=0;j<4;j++){
				cout<<m[i][j]<<" ";
			}
	return 0;
}

