#include <iostream>
using namespace std;

int main(int argc, char *argv[]) {
	int z[100],i,n;
	cout<<"ingrese cantidad de elementos: ";
	cin>>n;
	for (i=0;i<n;i++){
	cout<<"ingrese posici�n en la que desea almacenarlo: ";
	cin>>i;
	cout<<"ingrese valor a almacenar:";
	cin>>z[i];
	}
	for (i=0;i<n;i++){
	cout<<z[i]<<" "<<"posici�n: "<<i<<endl;
	}

	return 0;
}

