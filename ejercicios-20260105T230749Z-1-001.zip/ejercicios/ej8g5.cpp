#include <iostream>
#include <time.h> //libreria de semilla
using namespace std;

int main(int argc, char *argv[]) {
	srand(time(NULL)); //semilla empiece mas aleatoriamente que sin ella
	int Num=0,N,C,cont=0,may=0,i,cantgenerado=0;
	int numero[100];
	cout<<"ingrese el n�mero final de la lista:"<<endl;
	cin>>C;
	cout<<"ingrese el cantidad utilizada:"<<endl;
	cin>>N;
	//no puedo usar for porque no se cuantos valores voy a ingresar
	do{
	cantgenerado++;
	Num=(rand()%C)+1;
	cout<<"numero generado: "<<Num<<endl;
	if (Num>may){
		cout<<"ingreso en posici�n: "<<cont;
		may=Num;
		numero[cont]=Num;
		cont++;
	}
	}while(cantgenerado<N);
	for (int i=0;i<N;i++){
		cout<<numero[i]<<endl;
	}
	cout<<"cantidad generados: "<<cantgenerado;
	return 0;
}

