#include <iostream>
#include <string>
using namespace std;
int const n=3;///cambiar a 500
int main(int argc, char *argv[]) {
	string nombre[n],name,namemejor,namemayor;
	int i=0,cant[500],tiempo[500],mejor=500,mayor=0;
	cout<<"ingrese nombre del competidor:";
	cin>>name;
	while(name!="zzz"){
		nombre[i]=name;
		cout<<"ingrese cantidad de intentos:";
		cin>>cant[i];
		for(int j=0;j<cant[i];j++){
			cout<<"ingrese tiempo empleado en la clasificaci�n "<<(j+1)<<":";
			cin>>tiempo[j];
			if(tiempo[j]<mejor){
				mejor=tiempo[j];
				namemejor=name;
			}
			if(cant[i]>mayor){
				mayor=cant[i];
				namemayor=name;
			}
		}
		i++;
		cout<<"ingrese nombre del competidor:";
		cin>>name;
		cin.ignore();
	}
	for(int i=0;i<n;i++){
		cout<<"nombre: "<<nombre[i]<<"    cantidad de intentos: "<<cant[i]<<endl;
	}
	cout<<"mejor tiempo:"<<mejor<<endl;
	cout<<namemejor<<" fue el competidor con mejor tiempo: "<<mejor<<" minutos"<<endl;
	cout<<namemayor<<" fue el competidor que realizo mas intentos";
	return 0;
}

