#include <iostream>
#include <string>
using namespace std;
int const n=7;
int const x=31;
int main(int argc, char *argv[]) {
	int tipo[n],cabina,datos[x][3]={0},dia,cantI=0,cantVII=0,menor=500,aux;
	int t;
	for (int i=0;i<n;i++){
		cout<<"ingrese precio del vehiculo tipo "<<(i+1)<<":";
		cin>>tipo[i];
	}
	cout<<"AGOSTO 2019"<<endl;
	cout<<"ingrese tipo de vehiculo:";
	cin>>t;
	while(t!=0){
		if(t==1){
			cantI++;
		}
		if(t==7){
			cantVII++;
		}
		cout<<"ingrese d�a del mes:";
		cin>>dia;
		cout<<"ingrese cabina:";
		cin>>cabina;
		if (cabina==1){
			datos[dia][0]++;
		}else if(cabina==2){
			datos[dia][1]++;
		}else{
			datos[dia][2]++;
		}
		cout<<"ingrese tipo de vehiculo:";
		cin>>t;	
	}
	int total=datos[dia][0]+datos[dia][1]+datos[dia][2];
	cout<<"TOTAL DE VEHICULOS"<<endl;
	cout<<"DIA"<<"      "<<"CABINA 1"<<"      "<<"CABINA 2"<<"      "<<"CABINA 3"<<endl;
	for(int i=0;i<x;i++){
		if (datos[i][0]<menor){
			aux=i+1;
			menor=datos[i][1];
		}
		cout<<(i+1)<<"      "<<datos[i+1][0]<<"      "<<datos[i+1][1]<<"      "<<datos[i+1][2]<<endl;
	}
	cout<<"total recaudado de vehiculos tipo I: "<<(cantI*tipo[0])<<endl;
	cout<<"porcentaje de vehiculos tipo VII: "<<((cantVII*100)/total)<<endl;
	cout<<"el dia que la cabina 1 recibio menos vehiculos fue: "<<aux;
	return 0;
}

