#include <iostream>
#include <string>

using namespace std;

const int crea = 3; // 15
const int cven = 5; // 50

int main(){
    float precio[crea];
    int acu_cant_ven[crea];
    string vendedores[cven], ventas_tipo[100];
    int ventas[100][3];
    string aux_apenom;
    int aux_codven, c=0;
    float acu_mon_nac = 0, acu_mon_int = 0;

    for(int i = 0; i < crea; i++){
        cout << "Ingrese el precio del reactivo " << (i+1) << ": ";
        cin >> precio[i];

        acu_cant_ven[i] = 0;
    }
    
    for(int i=1; i <= cven; i++){
        cout << "Ingrese codigo de vendedor: ";
        cin >> aux_codven;

        cin.ignore();

        cout << "Ingrese el nombre del vendedor: ";
        getline(cin, aux_apenom);
        
        vendedores[aux_codven-1] = aux_apenom;
    }

    // for(int i=0; i<cven; i++){
    //     cout << (i+1) << " | " << vendedores[i] << endl;
    // }

    cout << "Infomacion de ventas: " << endl;
    cout << "ingrese codigo de vendedor: ";
    cin >> aux_codven;
    while(aux_codven != 99){
        ventas[c][0] = aux_codven; //col 0 = cod vendedor

        cout << "ingrese codigo de reactivo: ";
        cin >> ventas[c][1]; //col 1 = cod react

        cout << "ingrese la cantidad: ";
        cin >> ventas[c][2]; //col 2 = cant

        cout << "ingrese el tipo: ";
        cin >> ventas_tipo[c];
        
        c++;

        cout << "ingrese codigo de vendedor: ";
        cin >> aux_codven;
    }

    //informe A)
    cout << endl << endl;
    cout << "informe de ventas"<<endl;
    for(int i=0; i<c; i++){
        float auxmonto, auxpre;
        int auxcantidad, auxcodrea, auxcodven;
        string auxvendedor;

        auxcodven = ventas[i][0];
        auxcodrea = ventas[i][1];
        auxcantidad = ventas[i][2];

        auxpre = precio[auxcodrea-1];
        auxmonto = auxcantidad * auxpre;
        auxvendedor = vendedores[auxcodven-1];

        acu_cant_ven[auxcodrea-1] += auxcantidad;

        if(ventas_tipo[i] == "N"){
            //nacionales
            acu_mon_nac += auxmonto;
        }else{
            //internacionales
            acu_mon_int += auxmonto;
        }

        cout << "VENTA " << (i+1) << endl;
        cout << "CANTIDAD: " << auxcantidad << endl;
        cout << "MONTO: $" << auxmonto << endl;
        cout << "VENDEDOR: " << auxvendedor << endl;
        cout << "---------------" << endl;
    }

    //INFORME B
    cout << endl << endl;
    cout << "informe de montos:" << endl;
    cout << "nacionales: " << acu_mon_nac << endl;
    cout << "internacionales: " << acu_mon_int << endl;

    //INFORME C
    cout << endl << endl;
    cout << "informe de cantidad por reactivo:" << endl;
    for(int i=0; i<crea; i++){2
        cout << "reactivo " << (i+1) << ": " << acu_cant_ven[i] << endl;
    }


    return 0;
}