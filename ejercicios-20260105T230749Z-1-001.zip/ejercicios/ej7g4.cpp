#include <iostream>
#include <string>
using namespace std;

int main(int argc, char *argv[]) {
	string c1,c2,c3,aux1,aux2,aux3;
	cout<<"ingrese cadena:";
	getline(cin,c1);
	cout<<"ingrese cadena:";
	getline(cin,c2);
	cout<<"ingrese cadena:";
	getline(cin,c3);
	int n1=c1.size();
	int n2=c2.size();
	int n3=c3.size();
	if ((n1<n2)&&(n1<n3)) //copy and paste del ejercicio 1
	{
		aux1=c1;
		if (n2<n3)
			aux2=c2,aux3=c3;
		else 
			aux3=c2,aux2=c3;
	}
	if ((n2<n1)&&(n2<n3))
	{
		aux1=c2;
		if (n1<n3)
			aux2=c1,aux3=c3;
		else 
			aux3=c1,aux2=c3;
	}
	if ((n3<n1)&&(n3<n2))
	{
		aux1=c3;
		if (n1<n2)
			aux2=c1,aux3=c2;
		else 
			aux3=c1,aux2=c2;
	}
	cout<<aux1<<"  "<<aux2<<"  "<<aux3;
	return 0;
}

