#include <iostream>
#include <string>
using namespace std;

int main(int argc, char *argv[]) {
	string cadena;
	cout<<"ingrese cadena de caracteres:";
	getline(cin,cadena);
	int A=1;
	int B=cadena.size();
	cout<<B;
		cout<<cadena.substr(A,B-2);
	/*int n=cadena.size();
cadena.replace (0,2,"  ");
cadena.replace(n-2,n-3,"  ");
cout<<cadena;
		se resta -2 por ser windows en linea 12*/
	return 0;
}

