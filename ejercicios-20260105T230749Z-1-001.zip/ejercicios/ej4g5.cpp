#include <iostream>
using namespace std;

int main(int argc, char *argv[]) {
	int z[5],i,n=5;
	for (i=0; i<n; i++){
		cout<<"ingrese n�mero entero:";
		cin>>z[i];
	}
	for (i=0; i<n; i++){
		cout<<(z[i]*3)<<" ";
	}
	return 0;
}

