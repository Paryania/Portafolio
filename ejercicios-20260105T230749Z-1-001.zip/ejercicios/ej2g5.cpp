#include <iostream>
using namespace std;

int main(int argc, char *argv[]) {
	int NUM[10],max=0,imax;
	cout<<"ingrese numero entero:";
	cin>>NUM;
	for(int i=0;i<10;i++){
		cout<<(i+1);
		cin>[i]
	}

	cout<<"pares"<<endl;
	for(int i=0;i<10;i++){
		if(NUM[i]%2==0){
			cout<<NUM[i]<<"es par";
		}
	}
	for(int i=0;i<10;i++){
		if(NUM>max){
			max=NUM[i];
			imax=i;
		}
	}
	cout<<"el maximos es:"<<max<<"en la posici�n:"<<(imax+1);
	return 0;
}

