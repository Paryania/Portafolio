#include <iostream>
using namespace std;
int const n=150;///son 150
int main(int argc, char *argv[]) {
	float preciounitario[n];
	for(int i=0;i<n;i++){
		cout<<"ingrese precio del producto "<<(i+1)<<":";
		cin>>preciounitario[i];
	}
	cout<<"ventas por sucursal"<<endl;
	int cont1=0,suc,cantventas,cod,cantprod[n][5],suc88=0;
	while(cont1<5){
		cont1++;
		cout<<"ingrese codigo de sucursal:";
		cin>>suc;
		cout<<"ingrese cantidad de ventas:";
		cin>>cantventas;
		int cont2=0;
		while(cont2<cantventas){
			cont2++;
			cout<<"ingrese codigo de producto:";
			cin>>cod;
			cout<<"ingrese cantidad vendida:";
			cin>>cantprod[cod-1][suc];
			if (cod==88){
				suc88++;
			}
		}
	}
	cout<<"sucursales que vendieron el producto con codigo 88:"<<suc88<<endl;
	cout<<"sucursal 2"<<endl;
	cout<<"codigo de producto    cantidad    monto total"<<endl;
	for(int i=0;i<n;i++){
		cout<<(i+1)<<"    "<<cantprod[i][2]<<"    $"<<(cantprod[i][2]*preciounitario[i])<<endl;
	}
	float dat;
	int pos,band=0,i=0;
	cout<<"ingrese precio unitario a buscar:";
	cin>>dat;
	while(i<n){
		if(preciounitario[i]==dat){
			band=1;
			pos=i+1;
			i=n;
		}
		i++;
	}
	if(band==0){
		cout<<"precio no hallado";
	}else{
		cout<<"codigo de producto:"<<pos;
	}
	return 0;
}

