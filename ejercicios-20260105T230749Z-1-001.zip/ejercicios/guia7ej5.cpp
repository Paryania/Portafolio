#include <iostream>
using namespace std;
bool EVALUA(int &,int &,int &);
int N1,N2,N3;
int main(int argc, char *argv[]) {
	cout<<"ingrese primer nota: ";
	cin>>N1;
	cout<<"ingrese segunda nota: ";
	cin>>N2;
	cout<<"ingrese tercer nota: ";
	cin>>N3;
	bool BAND;
	BAND=EVALUA(N1,N2,N3);
	if(!BAND){
		cout<<"no promociona";
	}else{
		cout<<"promociona";
	}
	return 0;
}
bool EVALUA(int &N1,int &N2,int &N3){
	int suma;
	bool resultado=false;
	suma=N1+N2+N3;
	if ((N3>=25)&&(suma>=75)){
		resultado=true;
	}
	return resultado;
}
