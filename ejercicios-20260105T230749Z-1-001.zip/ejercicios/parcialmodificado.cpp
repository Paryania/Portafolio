#include <iostream>
#include <string>
using namespace std;
int const n=3;///320
int main(int argc, char *argv[]) {
	string postulante[n][3];
	cout<<"datos de los postulantes"<<endl;
	for(int i=0;i<n;i++){
		cout<<"ingrese dni del postulante:";
		cin>>postulante[i][0];
		cout<<"ingrese apellido y nombre:";
		cin>>postulante[i][1];
		cin.ignore();
		cout<<"ingrese telefono:";
		cin>>postulante[i][2];
	}
	cout<<"Resultados de las pruebas"<<endl;
	string dni;
	int cont=0,pos,cod,puntaje,resultado[n][4]={0};
	int punt[n]={0},cont2=0,acum=0,maximo=0,minimo=500;
	while(cont<n){
		cout<<"ingrese dni:";
		cin>>dni;
		int i=0;
		while(i<n){
			if(postulante[i][0]==dni){
				pos=i;
				i=n;
			}
			i++;
		}
		cont2=0;
		while(cont2<4){
		cout<<"ingrese codigo de prueba:";
		cin>>cod;
		cout<<"ingrese puntaje obtenido:";
		cin>>puntaje;
		resultado[pos][cod-1]=puntaje;
		cont2++;
		}
		cont++;
	}
	for(int i=0;i<n;i++){
		punt[i]=resultado[i][0]*2+resultado[i][1]*3+resultado[i][2]*4+resultado[i][3]*5;
		acum+=punt[i];
		if(punt[i]>maximo){
			maximo=punt[i];
		}
		if(punt[i]<minimo){
			minimo=punt[i];
		}
	}
	int aux1,aux2,aux3,aux4,aux5;
	string aux6,aux7,aux8;
	for(int i=0;i<(n-1);i++){
		for(int j=(i+1);j<n;j++){
			if(punt[i]<punt[j]){
				aux1=punt[i];
				punt[i]=punt[j];
				punt[j]=aux1;
				aux2=resultado[i][0];
				resultado[i][0]=resultado[j][0];
				resultado[j][0]=aux2;
				aux3=resultado[i][1];
				resultado[i][1]=resultado[j][1];
				resultado[j][1]=aux3;
				aux4=resultado[i][2];
				resultado[i][2]=resultado[j][2];
				resultado[j][2]=aux4;
				aux5=resultado[i][3];
				resultado[i][3]=resultado[j][3];
				resultado[j][3]=aux5;
				aux6=postulante[i][0];
				postulante[i][0]=postulante[j][0];
				postulante[j][0]=aux6;
				aux7=postulante[i][1];
				postulante[i][1]=postulante[j][1];
				postulante[j][1]=aux7;
				aux8=postulante[i][2];
				postulante[i][2]=postulante[j][2];
				postulante[j][2]=aux8;
			}
		}
	}
	cout<<"DNI   AF   CA   CO   CI    PUNTAJE FINAL"<<endl;
	for(int i=0;i<n;i++){
		cout<<postulante[i][0]<<"   "<<resultado[i][0]<<"   "<<resultado[i][1]<<"   "<<resultado[i][2]<<"   "<<resultado[i][3]<<"  "<<punt[i]<<endl;
	}
	float prom=(acum/n);
	cout<<"promedio total: "<<prom<<endl;
	cout<<"valor maximo: "<<maximo<<endl;
	cout<<"valor minimo: "<<minimo<<endl;
	cout<<"Puntajes que superan el promedio"<<endl;
	cout<<" dni   apellido y nombre   telefono   puntaje final"<<endl;
	for(int i=0;i<n;i++){
		if(punt[i]>=prom){
			cout<<postulante[i][0]<<"   "<<postulante[i][1]<<"   "<<postulante[i][2]<<"   "<<punt[i]<<endl;
		}
	}
	return 0;
}

