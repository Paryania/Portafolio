#include <iostream>
#include <string>
using namespace std;

int main(int argc, char *argv[]) {
	string nombre1,nombre2,nombre3,aux1,aux2,aux3;
	cout<< "ingrese primer nombre:";
	cin>> nombre1;
	cout<< "ingrese segundo nombre:";
	cin>> nombre2;
	cout<< "ingrese tercer nombre:";
	cin>> nombre3;
	
	if ((nombre1<nombre2)&&(nombre1<nombre3))
		{
		aux1=nombre1;
		if (nombre2<nombre3)
		aux2=nombre2,aux3=nombre3;
		else 
			aux3=nombre2,aux2=nombre3;
		}
	if ((nombre2<nombre1)&&(nombre2<nombre3))
	{
		aux1=nombre2;
		if (nombre1<nombre3)
			aux2=nombre1,aux3=nombre3;
		else 
			aux3=nombre1,aux2=nombre3;
	}
	if ((nombre3<nombre1)&&(nombre3<nombre2))
	{
		aux1=nombre3;
		if (nombre1<nombre2)
			aux2=nombre1,aux3=nombre2;
		else 
			aux3=nombre1,aux2=nombre2;
	}
		cout<<aux1<<"  "<<aux2<<"  "<<aux3;
	return 0;
}
