#include <iostream>
#include <string>
using namespace std;
int const n=20;///son20
int main(int argc, char *argv[]) {
	string nombre[n];
	for(int i=0;i<n;i++){
		cout<<"ingrese nombre del dato con codigo "<<(i+1)<<":";
		getline(cin,nombre[i]);
	}
	cout<<"datos de sitios web"<<endl;
	int cod,cont1=0,total=0;;
	string URL[n];
	float costo[n];
	while(cont1<5){
		cout<<"ingrese codigo del sitio:";
		cin>>cod;
		cout<<"ingrese URL:";
		cin>>URL[cod-1];
		cout<<"ingrese costo de descarga:";
		cin>>costo[cod-1];
		cont1++;
	}
	cout<<"datos de las descargas"<<endl;
	int soft,software[n][5]={0};
	cout<<"ingrese codigo de software:";
	cin>>soft;
	while(soft!=99){
		cout<<"ingrese codigo de sitio:";
		cin>>cod;
		software[soft-1][cod-1]++;
		total++;
		cout<<"ingrese codigo de software:";
		cin>>soft;
	}
	for(int i=0;i<n;i++){
	cout<<"codigo de software: "<<(i+1)<<"    nombre:"<<nombre[i]<<endl;//esto del codigo de software capaz es codigo de sitio y va con busqueda esta raro
	cout<<"URL del sitio     costo de descarga"<<endl;
	for(int j=0;j<n;j++){
		cout<<URL[j]<<"   "<<costo[j]<<endl;
	}
	cout<<endl;
	}
	cout<<endl;
	cout<<"total de descargas efectuadas: "<<total<<endl;
	cout<<"Nombre del soft    sitio 1    sitio 2     sitio 3       sitio 4     sitio 5"<<endl;
	for(int i=0;i<n;i++){
		cout<<nombre[i]<<"   ";
		for(int j=0;j<5;j++){
			cout<<software[i][j]<<"   ";
		}
		cout<<endl;
	}
	return 0;
}

