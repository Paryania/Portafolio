#include <iostream>
#include <iomanip>
#include <string>
using namespace std;
void formalinea(int,char);
int cant;
char car;
int main(int argc, char *argv[]) {
	formalinea(cant,car);
	return 0;
}
void formalinea(int cant,char car){
	string caracter;
	cout<<"ingrese cantidad: ";
	cin>>cant;
	cout<<"quiere especificar el caracter: ";
	cin>>caracter;
	if (caracter=="si"){
		cout<<"ingrese caracter: ";
		cin>>car;
	}else{
		cout<<setfill('#')<<setw(cant+1);
		cout<<" "<<endl;
	}
	cout<<setfill(car)<<setw(cant+1)<<endl;
	cout<<" "<<endl;
	
}
	
